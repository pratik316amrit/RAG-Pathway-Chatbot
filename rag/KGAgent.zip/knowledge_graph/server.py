
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import my_script
import uvicorn

app = FastAPI()

# Data model for input
class QueryModel(BaseModel):
    Query: str


@app.post("/process_query/")
async def process_query(data: QueryModel):
    query = data.Query
    try:
 
        result = my_script.get_entity_relations(query)

        # Save the result to a .txt file
        with open("output.txt", "w") as f:
            for line in result:
                f.write(line + "\n")
        
        return {"message": "Query processed and saved to output.txt", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
if __name__ == "__main__":
    # Start the Uvicorn server using an import string
    uvicorn.run("server:app", host="0.0.0.0", port=8002, reload=True)

