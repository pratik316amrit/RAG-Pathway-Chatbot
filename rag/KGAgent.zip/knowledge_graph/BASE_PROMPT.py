class PROMPTS:
    def __init__(self):
       # Corrected prompt template
        self.prompt = """
You are a financial analysis expert with deep knowledge of the following areas:
- Legal aspects of finance
- Risk management
- Stocks and securities
- Income from business activities
- Expenditures on business activities
- Liquid cash and liquidity
- Debt and liabilities
- Cash flow management
- Interest rate risk
- Chains of control and ownership structures

Please analyze the following text for **entities** and **relationships** within these financial and business contexts. Your task is to extract relevant information to form a list of **entities** and a list of **relationships** between them. Follow these steps:

### 1. **Entity Extraction**
   - Identify and list all entities mentioned in the text. The entities can be any of the following, with financial and business relevance:
     - **Companies or organizations** (e.g., "Company A," "XYZ Corp.")
     - **Financial instruments or assets** (e.g., "stocks," "bonds," "debt," "liquid cash," "capital expenditure")
     - **Financial concepts or metrics** (e.g., "interest rate risk," "cash flow," "income from business activity")
     - **Business activities or processes** (e.g., "acquired," "investment," "transaction")
     - **Other financial or business terms** (e.g., "net profit," "subsidiary," "parent company")
   
   Each entity should be clearly defined, reflecting its significance within the business or financial domain.

### 2. **Relation Extraction**
   - Identify meaningful relationships between the entities mentioned. For each relation, it should clearly express a **connection** or **interaction** between two entities within the business or financial context. Relationships can include:
     - **Business transactions or actions** (e.g., "acquired," "merged with," "invested in," "owns," "controls")
     - **Financial relations** (e.g., "affected by," "has risk of," "impacted by interest rate risk," "subject to")
     - **Organizational control** (e.g., "controlled by," "parent company of," "subsidiary of")
     - **Other business interactions** (e.g., "generated income from," "expenditure on")

   Each relationship should be formed as a **triplet**: (Entity 1, Relation, Entity 2). This means that for each relationship, two entities must be linked by a clear, defined relation.

### 3. **Relation Description**
   - For each relation identified in the "Relations" list, write a brief textual description explaining the relationship, drawing from the context in the original text. The description should provide additional context for why these entities are related and how they are interacting.
   
### 4. **Output Format**
   - Return the output as a **dictionary** in the following format:
     - **"Entities"**: List of all identified entities.
     - **"Relations"**: List of all identified relationships (formatted as triplets).
     - **"Relation Descriptions"**: List of descriptions explaining each relationship, corresponding in order to the "Relations" list.

     The dictionary format should look like:

     ```json
     
       "Entities": ["Entity 1", "Entity 2", "Entity 3", ...],
       "Relations": [("Entity 1", "Relation", "Entity 2"), ("Entity 3", "Relation", "Entity 4"), ...],
       "Relation Descriptions": [
         "Description of the first relation",
         "Description of the second relation",
         "Description of the third relation",
         ...
       ]
     
     ```

### 5. **Example**

Here is an example to guide you on how to extract entities, relations, and descriptions:

**Example Text**: 
"The XYZ Corp. merged with ABC Ltd., and now ABC Ltd. controls the operations of XYZ Corp. The merger has affected the company's cash flow, and the newly formed entity plans to issue bonds to generate capital."

**Entities**:
- XYZ Corp.
- ABC Ltd.
- Cash flow
- Bonds
- Capital

**Relations**:
- ("XYZ Corp.", "merged with", "ABC Ltd.")
- ("ABC Ltd.", "controls", "XYZ Corp.")
- ("merger", "affected", "cash flow")
- ("newly formed entity", "plans to issue", "bonds")
- ("bonds", "generate", "capital")

**Relation Descriptions**:
1. "XYZ Corp. merged with ABC Ltd. as part of a corporate restructuring strategy."
2. "ABC Ltd. now holds control over the operations of XYZ Corp. following the merger."
3. "The merger had a direct impact on the company's cash flow, as new operational structures were established."
4. "The newly formed entity, post-merger, plans to issue bonds in the market to raise funds."
5. "Bonds are being issued by the newly formed entity to generate capital for further expansion."

### Text for Analysis:
{chunk}

Please identify all entities and relationships from the text, describe each relation, and return them in the specified dictionary format.
"""




        