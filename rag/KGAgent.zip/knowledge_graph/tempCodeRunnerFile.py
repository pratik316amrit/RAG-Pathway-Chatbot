import requests
response = requests.post("http://127.0.0.1:8000/process_query/", json={"query": "Google"})
print(response.json())