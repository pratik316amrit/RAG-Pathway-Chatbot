import requests

# Define the URL of the FastAPI server
url = "http://127.0.0.1:8002/process_query/"

# Define the data to be sent in the POST request
data = {
    "Query": "Google acquisitions"
}

# Send a POST request to the FastAPI server
response = requests.post(url, json=data)

# Check the status code and print the response
if response.status_code == 200:
    print("Response received successfully")
    print("Response JSON:", response.json())
else:
    print(f"Error {response.status_code}: {response.text}")
