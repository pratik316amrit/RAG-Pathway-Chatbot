import re
import json
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv
import os
from BASE_PROMPT import PROMPTS
load_dotenv()
api_key=os.getenv("GOOGLE_API_KEY")
llm=ChatGoogleGenerativeAI(model='gemini-1.5-flash',api_key=api_key)
import ast
from collections import defaultdict
import networkx as nx

file_dir = r"/Users/rishikantchigrupaatii/Documents/Pathway/lesgo/Pathway_chatbot/rag/knowledge_graph/parsed_docs.txt"  

def load_file_as_string(filename, encoding='utf-8'):
    try:
        with open(filename, 'r', encoding=encoding) as file:
            data = file.read() 
        return data
    except UnicodeDecodeError as e:
        print(f"UnicodeDecodeError: {e}. Trying with a different encoding.")
        with open(filename, 'r', encoding='latin1') as file:
            data = file.read()
        return data


# Function to extract text and metadata and create the tuple
def parse_text_file(data):
    # Split the data into separate sections by Text and Metadata pairs
    sections = re.split(r'\n(?=Text:)', data.strip())  # Split by 'Text:' heading
    
    result = []
    
    for section in sections:
        # Split the section into Text and Metadata
        text_match = re.search(r'Text: (.*?)\n', section)
        metadata_match = re.search(r'Metadata: (.*)', section)
        
        if text_match and metadata_match:
            # Extract the text and metadata
            text = text_match.group(1).strip()
            if len(text.strip())<5:continue
            metadata_str = metadata_match.group(1).strip()
            
            # Convert metadata string to a dictionary
            metadata = json.loads(metadata_str.replace("'", "\""))
            
            # Check if 'parent_id' is in the metadata
            parent_id = metadata.get('parent_id', None)
            
            # Create a tuple (Text, {Parent_id: parent_id})
            result.append((text, {'Parent_id': parent_id} if parent_id else 'None'))
    
    return result

def chunks_former(file_dir,chunk_club_size=10): 
    chunks=[]
    parsed_text = parse_text_file(load_file_as_string(file_dir))
    while(parsed_text):
        chunk=""
        for i in range(chunk_club_size):
            try:
                chunk+=parsed_text[0][0]+'\n'
                parsed_text.pop(0)
            except:
                break
        chunks.append(chunk)
    return chunks


def Entity_Relation_Generator(chunk):
    template = PROMPTS().prompt
    prompt=ChatPromptTemplate.from_template(template)
    generate_prompt_chain=prompt|llm|StrOutputParser()
    return generate_prompt_chain.invoke({"chunk":chunk})


def Entity_Relation_Dict(text):
    # The input string with Markdown formatting
    input_string = Entity_Relation_Generator(text)

    # Step 1: Remove the Markdown formatting
    input_string = input_string.replace('```json\n', '').replace('```', '')

    # Step 2: Replace parentheses with square brackets in the "Relations" section
    input_string = input_string.replace('(', '[').replace(')', ']')

    # Step 3: Use ast.literal_eval to safely evaluate the string as a Python dictionary
    return ast.literal_eval(input_string)

def Entity_Relation_Entity(chunks):
    main_dict=[]
    for text in chunks:
        main_dict.append(Entity_Relation_Dict(text))
    for i,entity_relation_description in enumerate(main_dict):
        entity_relation_description['Relation Descriptions']=list(set(entity_relation_description['Relation Descriptions']))
        entity_relation_description['Text']=chunks[i]
    triplets_dict=defaultdict(set)
    for entity_relation_description in main_dict:
        for relation in entity_relation_description['Relations'] :
            triplets_dict[tuple([relation[0],relation[-1]])].update(entity_relation_description['Relation Descriptions'])
    triplets_tuple_list=[]
    for entity1,entity2 in triplets_dict:
        triplets_tuple_list.append(tuple([entity1,triplets_dict[(entity1,entity2)],entity2]))
    return triplets_tuple_list

def build_graph(triplets):
    G = nx.DiGraph()
    for source, relations, target in triplets:
        for relation in relations:
            G.add_edge(source, target, relation=relation)
    return G

G=None
try: 
    G = nx.read_graphml("knowledge_graph.graphml")
except:
    print("Hello")
    G = build_graph(Entity_Relation_Entity(chunks_former(file_dir,chunk_club_size=10)))
    nx.write_graphml(G, "knowledge_graph.graphml")
    
def get_entity_relations(Query,graph=G):
    print("In here")
    relations = set()
    Triplets=Entity_Relation_Entity([Query])
    entities=set()
    for Triplet in Triplets:
        entities.add(Triplet[0])
        entities.add(Triplet[-1])
        
    for entity in entities:    
        for source, target, data in graph.edges(data=True):
            if source == entity or target == entity:
                #print("Edge data:", data)  # Full edge data
                if 'relation' in data:  # Check if 'relation' exists in data
                    print("Relation:", data['relation'])
                    relations.add(data.get('relation'))

                
                
                
    return list(relations)

def main():
    print("hi")
    get_entity_relations("Google")
    
if __name__ == "__main__":
    main()